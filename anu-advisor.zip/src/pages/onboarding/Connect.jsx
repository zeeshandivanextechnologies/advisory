import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function Connect() {
  const { user }   = useAuth();
  const navigate   = useNavigate();
  const dashPath   = user?.role === 'advisor' ? '/advisor/dashboard' : '/user/dashboard';

  return (
    <div className="onboarding-layout">
      <nav className="onboarding-nav">
        <span style={{ fontFamily: 'var(--font-h)', fontSize: 15, fontWeight: 700, color: 'var(--text-1)' }}>
          AunAdvisory
        </span>
      </nav>

      <div className="onboarding-body">
        <div className="onboarding-card">
          <div style={{ fontSize: 52, marginBottom: 16 }}>🚀</div>
          <h2>You're all set!</h2>
          <p className="onboarding-subtitle">
            Your profile is complete. You can now connect with verified advisors, create cases, and upload documents — all in one place.
          </p>

          <div className="progress-dots">
            <span className="progress-dot" />
            <span className="progress-dot" />
            <span className="progress-dot active" />
          </div>

          <div style={{
            background: 'var(--hover-card)', border: '1px solid var(--border-dk)',
            borderRadius: 'var(--radius)', padding: '16px 18px',
            margin: '24px 0', textAlign: 'left',
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--secondary-col)', fontFamily: 'var(--font-h)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 10 }}>
              What's next
            </div>
            {[
              '📋  Create your first advisory case',
              '📄  Upload required documents',
              '👤  Connect with a verified advisor',
              '📅  Book your first consultation',
            ].map(step => (
              <div key={step} style={{ fontSize: 13, color: 'var(--text-2)', padding: '5px 0', fontFamily: 'var(--font-b)' }}>
                {step}
              </div>
            ))}
          </div>

          <button
            className="btn btn-primary"
            style={{ width: '100%', padding: '13px' }}
            onClick={() => navigate(dashPath)}
          >
            Go to Dashboard →
          </button>
        </div>
      </div>
    </div>
  );
}
