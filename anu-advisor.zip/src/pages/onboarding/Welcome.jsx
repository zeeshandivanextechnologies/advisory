import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function Welcome() {
  const { user } = useAuth();
  const navigate  = useNavigate();

  return (
    <div className="onboarding-layout">
      <nav className="onboarding-nav">
        <span style={{ fontFamily: 'var(--font-h)', fontSize: 15, fontWeight: 700, color: 'var(--text-1)' }}>
          AunAdvisory
        </span>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/user/dashboard')}>
          Skip →
        </button>
      </nav>

      <div className="onboarding-body">
        <div className="onboarding-card">
          <div style={{ fontSize: 52, marginBottom: 16 }}>🎉</div>
          <h2>Welcome, {user?.full_name?.split(' ')[0]}!</h2>
          <p className="onboarding-subtitle">
            Your account is ready. Let's get you set up so we can match you with the right advisor for your business needs.
          </p>

          <div className="progress-dots" style={{ marginTop: 24 }}>
            <span className="progress-dot active" />
            <span className="progress-dot" />
            <span className="progress-dot" />
          </div>

          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12,
            margin: '24px 0',
          }}>
            {[
              { icon: '⚡', text: 'Expert advisors available now' },
              { icon: '🔒', text: 'Fully secure & confidential' },
              { icon: '🌍', text: 'GCC jurisdiction specialists' },
              { icon: '📋', text: 'End-to-end case management' },
            ].map(({ icon, text }) => (
              <div key={text} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 14px', background: 'var(--hover-card)',
                border: '1px solid var(--border-dk)', borderRadius: 'var(--radius-sm)',
              }}>
                <span>{icon}</span>
                <span style={{ fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-b)' }}>{text}</span>
              </div>
            ))}
          </div>

          <button
            className="btn btn-primary"
            style={{ width: '100%', padding: '13px' }}
            onClick={() => navigate('/onboarding/needs')}
          >
            Get Started →
          </button>
        </div>
      </div>
    </div>
  );
}




