import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const NEEDS = [
  { icon: '🏢', label: 'Start a Business',  desc: 'Company formation & registration in the GCC' },
  { icon: '📜', label: 'Get a License',     desc: 'Business licensing & trade permits' },
  { icon: '🛂', label: 'Visa & Residency',  desc: 'Work permits & residency applications' },
  { icon: '💰', label: 'Tax Advisory',      desc: 'VAT, corporate tax & compliance' },
  { icon: '📋', label: 'Contract Review',   desc: 'Legal document drafting & review' },
  { icon: '✅', label: 'Compliance',        desc: 'Regulatory & corporate governance' },
  { icon: '™️',  label: 'Trademark / IP',   desc: 'Brand protection & IP rights' },
  { icon: '🤝', label: 'M&A Advisory',      desc: 'Mergers, acquisitions & due diligence' },
];

export default function Needs() {
  const navigate         = useNavigate();
  const [selected, setSelected] = useState([]);

  const toggle = (label) =>
    setSelected(prev =>
      prev.includes(label) ? prev.filter(x => x !== label) : [...prev, label]
    );

  return (
    <div className="onboarding-layout">
      <nav className="onboarding-nav">
        <span style={{ fontFamily: 'var(--font-h)', fontSize: 15, fontWeight: 700, color: 'var(--text-1)' }}>
          AunAdvisory
        </span>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/onboarding/connect')}>
          Skip →
        </button>
      </nav>

      <div className="onboarding-body">
        <div className="onboarding-card" style={{ maxWidth: 620 }}>
          <h2>What do you need help with?</h2>
          <p className="onboarding-subtitle">
            Select all that apply — we'll personalise your advisory experience
          </p>

          <div className="progress-dots">
            <span className="progress-dot" />
            <span className="progress-dot active" />
            <span className="progress-dot" />
          </div>

          <div className="needs-grid">
            {NEEDS.map(({ icon, label, desc }) => (
              <div
                key={label}
                className={`need-option${selected.includes(label) ? ' selected' : ''}`}
                onClick={() => toggle(label)}
              >
                <div className="need-icon">{icon}</div>
                <h5>{label}</h5>
                <p>{desc}</p>
                {selected.includes(label) && (
                  <div style={{
                    position: 'absolute', top: 10, right: 12,
                    fontSize: 14, color: 'var(--secondary-col)',
                  }}>✓</div>
                )}
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            <button className="btn btn-outline" onClick={() => navigate('/onboarding/welcome')}>
              ← Back
            </button>
            
            <button
              className="btn btn-primary"
              style={{ flex: 1 }}
              onClick={() => navigate('/onboarding/connect')}
              disabled={!selected.length}
            >
              Continue ({selected.length} selected) →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
